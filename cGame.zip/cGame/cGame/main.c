#include "include/raylib.h"
#include <stdio.h>

#define birdStartX 100
#define gravity 0.2f
#define birdStartY 313
#define numberBirds 3 
#define numberPigs 1
#define groundY 395


// Kuş yapısı
typedef struct Bird {
    Texture2D texture;
    int x;
    int y;
    bool isBirdFired;
    bool isBirdSelected;
    Vector2 mouseStartPosition;
    Vector2 velocity;
    Music birdsound;
} Bird;

typedef struct Pig{
    Texture2D texture;
    int x;
    int y;
} Pig;

typedef struct {
    Texture2D texture;
    int x;
    int y;
    Vector2 velocity;
} Block;

typedef struct {
    Texture2D texture;
    int x;
    int y;
    bool collapse;
    Vector2 position;
    Rectangle sourceRec;
    Vector2 origin;
    float rotation;
    bool collapseRight;
    bool collisionDetected;
    bool isItAbove;
    bool collapseFinished;
} Wood_v;

typedef struct {
    Texture2D texture;
    int x;
    int y;
    bool collapse;
    bool collisionDetected;
    bool isItAbove;
} Wood_h;

typedef struct{
    Bird bird;
    bool collesion;
} CollesionResult;

typedef enum {
    MAIN_PAGE,
    INFO_PAGE,
    MENU_PAGE,
    GAME1_PAGE,
    GAME2_PAGE,
    GAME3_PAGE,
} PageState;

void catapultSystem(Bird *bird, Music birdFiredSound);
void initializeBird(Bird *bird);
int isItOutOfArea(Bird *bird); 
void initializePig(Pig *pig, PageState pageState);
bool CheckCollisionWithPig(Bird *bird, Pig *pig);
bool CheckCollisionWithBlock(Bird *bird, Rectangle Block);
void resetGame(Bird *birds, Pig *pigs, Wood_v *woodV, Wood_h *woodH, bool *isCollision, PageState pageState);
void findScore(Bird *birds, Pig *pigs, Wood_v *woodV, Wood_h *woodH, bool *isCollision, Texture2D *scoreTable, PageState *pageState);
void initializeButtons(Rectangle *playButton, Rectangle *game1Button, Rectangle *game2Button, Rectangle *game3Button, Rectangle *gameBackButton, Rectangle *gameRestartButton, Rectangle *mainBackButton, Rectangle *closeButton, Rectangle *infoButton);
void initializePageTextures(Texture2D *mainPage, Texture2D *menuPage, Texture2D *infoScreen, Texture2D *scoreTable, Texture2D *textureForTable, int screenWidth, int screenHeight);

CollesionResult checkCollisionBirdWood(Bird* bird, Wood_v* wood);
CollesionResult checkCollisionBirdWoodh(Bird* bird, Wood_h* wood);

//3 

void checkCollision(Bird *birds, Wood_v *woodV, Wood_h *woodH);
void updateWood(Wood_v* woodV); 
void initializeWood(Wood_v *woodV, Wood_h *woodH, bool *isCollision, PageState pageState);
void rightToLaunch(Bird *birds, Texture2D textureForTable);
void initializeGameObjects(Texture2D *catapult, Texture2D *pigExplosion, Texture2D *ground, Texture2D *stoneBlock);


int main(void) {
    
    const int screenWidth = 1100;
    const int screenHeight = 500;
    
    InitWindow(screenWidth, screenHeight, "Angry Birds");
    InitAudioDevice(); 
    
    //MAIN OBJECTS
    PageState pageState;
    Music themeMusic;
    Texture2D mainPage , menuPage, infoScreen, scoreTable[4], textureForTable;
    Rectangle playButton, game1Button, game2Button, game3Button, gameBackButton, gameRestartButton, mainBackButton, closeButton, infoButton;
    
    pageState = MAIN_PAGE;
    
    themeMusic = LoadMusicStream("TexturesAudio/themeMusic.mp3");
    PlayMusicStream(themeMusic);
    SetMusicVolume(themeMusic, 0.5f);
    
    initializeButtons(&playButton, &game1Button, &game2Button, &game3Button, &gameBackButton, &gameRestartButton, &mainBackButton, &closeButton, &infoButton);
    initializePageTextures(&mainPage, &menuPage, &infoScreen, scoreTable, &textureForTable, screenWidth, screenHeight);
    
    
    // GAME1 PAGE
    
    Bird birds[numberBirds];
    Pig pigs[numberPigs];

    Texture2D catapult, ground, pigExplosion, stoneBlock;
    const int catapultX = 70;
    const int catapultY = 320;
    
    initializeGameObjects(&catapult, &pigExplosion, &ground, &stoneBlock);
    // GAME2
    
    bool isCollision = false;
    //bool isCollisionwoodh = true;
    
    // GAME3
    
    Wood_h woodH[3];
    Wood_v woodV[6];
    
    
    SetTargetFPS(60);

    while (!WindowShouldClose()) {

        // Müzik akışını güncelleme
        UpdateMusicStream(themeMusic);
        
        //Start Drawing
        BeginDrawing();
        
        //Draw Background
        ClearBackground(SKYBLUE);
        
        
        switch (pageState) {
                
            case MAIN_PAGE:
                
                DrawTexture(mainPage, 0, 0, WHITE);
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), playButton)) {
                    pageState = MENU_PAGE;
                }
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), infoButton)) {
                    pageState = INFO_PAGE;
                }
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), closeButton)) {
                    CloseWindow();
                }
                
                break;
                
            case INFO_PAGE:
                
                DrawTexture(infoScreen, 0, 0, WHITE);
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), infoButton)) {
                    pageState = MAIN_PAGE;
                }
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), closeButton)) {
                    CloseWindow();
                }
                
                break;
                    
            case MENU_PAGE:
                
                DrawTexture(menuPage, 0, 0, WHITE);
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), game1Button)) {
                    pageState = GAME1_PAGE;
                    resetGame(birds, pigs, woodV, woodH, &isCollision, pageState);
                }
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), game2Button)) {
                    pageState = GAME2_PAGE;
                    resetGame(birds, pigs, woodV, woodH, &isCollision, pageState);
                }
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), game3Button)) {
                    pageState = GAME3_PAGE;
                    resetGame(birds, pigs, woodV, woodH, &isCollision, pageState);
                }
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), mainBackButton)) {
                    pageState = MAIN_PAGE;
                }
                
                break;
                
                
            case GAME1_PAGE:
                    
                // Draw Ground
                DrawTexture(ground, 0, 0, WHITE);
                
                // Draw Catapult
                DrawTexture(catapult, catapultX, catapultY, WHITE);
                
                // Draw Pigs
                DrawTexture(pigs[0].texture, pigs[0].x, pigs[0].y, WHITE);
                
                rightToLaunch(birds, textureForTable);
                
                //Draw Object
                DrawTexture(stoneBlock, 695, 365, WHITE);
                Rectangle stoneBlockRect = { 695, 365, 60, 60}; // stoneBlock dikdörtgen sınırları
                
                // Draw Birds and Run catapultSystem 
                // Şimdilik bulduğum çözüm bu, ileride düzenleştirilir. Şimdilik 3 kez fırlatılabiliyor.
               
                for(int i =0 ; i<3 ;i++){
                    
                    if (i==0) {
                        DrawTexture(birds[i].texture, birds[i].x, birds[i].y, WHITE);
                        catapultSystem(&birds[i], birds[i].birdsound);
                        
                    }
                    
                    else{
                        if (isItOutOfArea(&birds[i-1]) == 1){
                            DrawTexture(birds[i].texture, birds[i].x, birds[i].y, WHITE);
                            catapultSystem(&birds[i], birds[i].birdsound); 
                        }
                    }

                    UpdateMusicStream(birds[i].birdsound); 
                    
                    if (CheckCollisionWithBlock(&birds[i], stoneBlockRect)){
                        PauseMusicStream(birds[i].birdsound);
                        
                        if(birds[i].y <= 365 && birds[i].x >= 695){
                            birds[i].velocity = (Vector2){0, 0}; 
                        }else{
                            birds[i].velocity.x = 0; 
                        }
                    }
                    
                    if (CheckCollisionWithPig(&birds[i], &pigs[0])) {
                        pigs[0].x = -100;
                        pigs[0].y = -100;
                    
                    }
                
                }
                if (pigs[0].x == - 100 && pigs[0].y == -100) {
                    DrawTexture(pigExplosion, 700, 315, WHITE);
                }
                
                //SCORE TABLE
                findScore(birds, pigs, woodV, woodH, &isCollision, scoreTable, &pageState);

                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), gameBackButton)) {
                    pageState = MENU_PAGE;
                }   
                    
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), gameRestartButton)) {
                    resetGame(birds, pigs, woodV, woodH, &isCollision, pageState);
                }
                    
                break;        
                
            case GAME2_PAGE:
                // Draw Ground
                DrawTexture(ground, 0, 0, WHITE);
                
                // Draw Catapult
                DrawTexture(catapult, catapultX, catapultY, WHITE);                
                DrawTexture(pigs[0].texture, pigs[0].x, pigs[0].y, WHITE);
                
                rightToLaunch(birds, textureForTable);
                
                // 3 KEZ KUŞU ÇAĞIRMA VE FONKSİYONLARINI ÇAĞIRMA
                
                for(int i =0 ; i<3 ;i++){
                    
                    if (i==0) {
                        DrawTexture(birds[i].texture, birds[i].x, birds[i].y, WHITE);
                        catapultSystem(&birds[i], birds[i].birdsound);
                        
                    }
                    
                    else{
                        if (isItOutOfArea(&birds[i-1]) == 1){
                            DrawTexture(birds[i].texture, birds[i].x, birds[i].y, WHITE);
                            catapultSystem(&birds[i], birds[i].birdsound); 
                        }
                    }

                    UpdateMusicStream(birds[i].birdsound); 
                }
                
                DrawTexture(woodH[0].texture, woodH[0].x, woodH[0].y, WHITE);
                
                Bird Tbird;
                
                // Tüm(3) kuşların çarpışmasını kontrol ediyor 
                woodV[0].collisionDetected = checkCollisionBirdWood(birds, &woodV[0]).collesion;
                woodH[0].collisionDetected = checkCollisionBirdWoodh(birds, &woodH[0]).collesion;
                
                
                if (checkCollisionBirdWood(birds, &woodV[0]).collesion || checkCollisionBirdWoodh(birds, &woodH[0]).collesion) {
                    Tbird = checkCollisionBirdWood(birds, &woodV[0]).bird;
                }
                
                for (int i = 0; i < 3; i++) {
                    if (checkCollisionBirdWood(birds, &woodV[0]).collesion || checkCollisionBirdWoodh(birds, &woodH[0]).collesion) {
                        birds[i].velocity.x = 0;
                        birds[i].velocity.y = 0;
                        
                        birds[i].x = 2000;  // YOK ETME
                    }
                }
                
                checkCollision(&Tbird, &woodV[0], &woodH[0]);
                
                //DOMUZU YOK ETME
                if (woodV[0].collapseFinished) {
                    pigs[0].x = -100;
                    pigs[0].y = -100;
                    DrawTexture(pigExplosion, 745, 370, WHITE);
                }
                
                //SCORE TABLE
                findScore(birds, pigs, woodV, woodH, &isCollision, scoreTable, &pageState);
                
                //Buttons
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), gameBackButton)) {
                    pageState = MENU_PAGE;
                }   
                    
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), gameRestartButton)) {
                    resetGame(birds, pigs, woodV, woodH, &isCollision, pageState);
                }
                
                
                break;
            
            case GAME3_PAGE:
                // Draw Ground
                DrawTexture(ground, 0, 0, WHITE);
                
                // Draw Catapult
                DrawTexture(catapult, catapultX, catapultY, WHITE);
                
                DrawTexture(pigs[0].texture, pigs[0].x, pigs[0].y, WHITE);
                
                rightToLaunch(birds, textureForTable);
                
                // 3 KEZ KUŞU VE FONKSİYONLARINI ÇAĞIRMA
                for(int i =0 ; i<3 ;i++){
                    if (i==0) {
                        DrawTexture(birds[i].texture, birds[i].x, birds[i].y, WHITE);
                        catapultSystem(&birds[i], birds[i].birdsound);
                        
                    }
                    
                    else{
                        if (isItOutOfArea(&birds[i-1]) == 1){
                            DrawTexture(birds[i].texture, birds[i].x, birds[i].y, WHITE);
                            catapultSystem(&birds[i], birds[i].birdsound); 
                        }
                    }
                    UpdateMusicStream(birds[i].birdsound); 
                }
                
                //
                //GAME
                //
                
                DrawTexture(woodH[0].texture, woodH[0].x, woodH[0].y, WHITE);
                DrawTexture(woodH[1].texture, woodH[1].x, woodH[1].y, WHITE);
                DrawTexture(woodH[2].texture, woodH[2].x, woodH[2].y, WHITE);
                
                Bird TBird1;
                
                //
                woodV[0].collisionDetected = checkCollisionBirdWood(birds, &woodV[0]).collesion;
                woodH[0].collisionDetected = checkCollisionBirdWoodh(birds, &woodH[0]).collesion;
                
                woodV[2].collisionDetected = checkCollisionBirdWood(birds, &woodV[2]).collesion;
                woodH[1].collisionDetected = checkCollisionBirdWoodh(birds, &woodH[1]).collesion;
                
                woodV[4].collisionDetected = checkCollisionBirdWood(birds, &woodV[4]).collesion;
                woodH[2].collisionDetected = checkCollisionBirdWoodh(birds, &woodH[2]).collesion;
            
                if(woodV[0].collisionDetected || woodH[0].collisionDetected){
                    isCollision = true;
                    TBird1 = checkCollisionBirdWood(birds, &woodV[0]).bird;
                }
                
                if(woodV[2].collisionDetected || woodH[1].collisionDetected){
                    TBird1 = checkCollisionBirdWood(birds, &woodV[2]).bird;
                }
                
                if(woodV[4].collisionDetected || woodH[2].collisionDetected){
                    TBird1 = checkCollisionBirdWood(birds, &woodV[4]).bird;

                }
                
                checkCollision(&TBird1, &woodV[0], &woodH[0]); //1
                
                if (isCollision) {
                    if (woodV[0].collapseRight) {
                        woodV[2].collisionDetected = checkCollisionBirdWood(birds, woodV).collesion;
                        woodH[1].collisionDetected = checkCollisionBirdWoodh(birds, woodH).collesion;
                        if (woodV[4].collapse == false) {
                            woodV[4].collisionDetected = checkCollisionBirdWood(birds, woodV).collesion;
                            woodH[2].collisionDetected = checkCollisionBirdWoodh(birds, woodH).collesion;
                            
                            woodV[4].isItAbove = true;
                            woodV[5].isItAbove = true;
                            woodH[2].isItAbove = false;
        
                        }
                    }
                    
                    if(!(woodV[0].collapseRight)){
                        woodV[2].collisionDetected = checkCollisionBirdWood(birds, &woodV[2]).collesion;
                        woodH[1].collisionDetected = checkCollisionBirdWoodh(birds, &woodH[1]).collesion;
                        
                        if (woodV[4].collapse == false) {
                            woodV[4].collisionDetected = checkCollisionBirdWood(birds, woodV).collesion;
                            woodH[2].collisionDetected = checkCollisionBirdWoodh(birds, woodH).collesion;
                            
                            
                            woodV[4].isItAbove = true;
                            woodV[5].isItAbove = false;
                            woodH[2].isItAbove = false;
                            
                        }
                    }
                }
                
                checkCollision(&TBird1, &woodV[2], &woodH[1]); //2
                checkCollision(&TBird1, &woodV[4], &woodH[2]); //3
                
            
 
                for (int i = 0; i < numberBirds; i++) {
                    if (checkCollisionBirdWood(birds, &woodV[0]).collesion || checkCollisionBirdWoodh(birds, &woodH[0]).collesion) {
                        birds[i].velocity= (Vector2){0,0};                     
                        birds[i].x = 2000;
                    }
                    
                    if (checkCollisionBirdWood(birds, &woodV[2]).collesion || checkCollisionBirdWoodh(birds, &woodH[1]).collesion) {
                        birds[i].velocity= (Vector2){0,0}; 
                        birds[i].x = 2000;
                    }
                    
                    if (checkCollisionBirdWood(birds, &woodV[4]).collesion || checkCollisionBirdWoodh(birds, &woodH[2]).collesion) {
                        birds[i].velocity= (Vector2){0,0}; 
                        birds[i].x = 2000;
                    }
                }
                
                //DOMUZU YOK ETME
                
                if (woodV[2].collapseFinished) {
                    pigs[0].x = -100;
                    pigs[0].y = -100;
                }
                
                // PIG EXLOSION
                if (pigs[0].x == -100 && pigs[0].y == -100) {
                    DrawTexture(pigExplosion, 830, groundY-25, WHITE);
                }
                
                //SCORE TABLE
                findScore(birds, pigs, woodV, woodH, &isCollision, scoreTable, &pageState);
                
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), gameBackButton)) {
                    pageState = MENU_PAGE;
                }   
                    
                if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), gameRestartButton)) {
                    resetGame(birds, pigs, woodV, woodH, &isCollision, pageState);
                }
                
                break;
             
                
            default:
                break;
        }
        
        EndDrawing();
    }
    
    UnloadMusicStream(themeMusic);  
    UnloadMusicStream(birds[0].birdsound); 
    UnloadMusicStream(birds[1].birdsound); 
    UnloadMusicStream(birds[2].birdsound);  
    
    CloseWindow();
    
    return 0;
}

void catapultSystem(Bird *bird, Music birdFiredSound){
    
    const float velocityMultiplier = 0.2f; // Hız çarpanı
    //kuş sınrları
    const int dragBoundaryLeft = 10;
    const int dragBoundaryRight = 100;
    const int dragBoundaryTop = 213;
    const int dragBoundaryBottom = 385;
    
    // Check if the bird is selected
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && !bird->isBirdSelected &&
        CheckCollisionPointRec(GetMousePosition(), (Rectangle){bird->x, bird->y, bird->texture.width, bird->texture.height})) {
        bird->isBirdSelected = true;
        bird->mouseStartPosition = GetMousePosition();
    }
    
    // Drag and release the bird
    if (bird->isBirdSelected && !bird->isBirdFired) {
        // Update bird position while dragging
        bird->x = GetMouseX() - bird->texture.width / 2;
        bird->y = GetMouseY() - bird->texture.height / 2;
        
        if (bird->isBirdSelected) {
            
            //        if (bird->x < dragBoundaryLeft || bird->x > dragBoundaryRight || bird->y < dragBoundaryTop || bird->y > dragBoundaryBottom) {
            if (bird->x <  dragBoundaryLeft) {
                bird->x = dragBoundaryLeft;
            }
            if (bird->x > dragBoundaryRight) { 
                bird->x = dragBoundaryRight;
            }
            if (bird->y < dragBoundaryTop) { 
                bird->y = dragBoundaryTop;
            }
            if (bird->y > dragBoundaryBottom) {
                bird->y = dragBoundaryBottom ;
            }
            
        }
        
        
        // Release the bird
        if (IsMouseButtonReleased(MOUSE_LEFT_BUTTON)) {
            bird->isBirdSelected = false;
            bird->isBirdFired = true; // Kuş fırlatıldı
            // Calculate bird velocity based on drag distance
            Vector2 mouseEndPosition = GetMousePosition();
            bird->velocity.x = (bird->mouseStartPosition.x - mouseEndPosition.x) * velocityMultiplier; // Ters yönde fırlatma
            bird->velocity.y = (bird->mouseStartPosition.y - mouseEndPosition.y) * velocityMultiplier; // Ters yönde fırlatma
        }
    }
    
    // Move the bird based on the calculated velocity
    if (bird->isBirdFired) {
        bird->x += (int)bird->velocity.x;
        bird->y += (int)bird->velocity.y;
        
        // Apply gravity to the bird
        bird->velocity.y += gravity;
        
        PlayMusicStream(birdFiredSound);
    }
    
    
    if (isItOutOfArea(bird) == 1) {
        // Handle collision
        // Burada çarpışma durumunu işleyebilirsiniz. Örneğin, kuşu yeniden başlatabilirsiniz.

        bird->velocity = (Vector2){0, 0}; // Hızı sıfırla
        
        PauseMusicStream(birdFiredSound);
    }
    
    
}

void initializeBird(Bird *birds){
    for (int i = 0; i < numberBirds; i++) {
        birds[i].texture = LoadTexture("TexturesAudio/redBird.png");
        birds[i].texture.width /= 17;
        birds[i].texture.height /= 17;
        birds[i].x = birdStartX; // Her bir kuşun başlangıç konumunu ayarlayın
        birds[i].y = birdStartY;
        birds[i].isBirdFired = false; // Başlangıçta hiçbir kuş fırlatılmamış
        birds[i].isBirdSelected = false; // Başlangıçta hiçbir kuş seçilmemiş
        birds[i].birdsound= LoadMusicStream("TexturesAudio/birdFiredSound.mp3");
    }
}

void initializePig(Pig *pig, PageState pageState){
    
    pig[0].texture = LoadTexture("TexturesAudio/pig.png");
    pig[0].texture.width = 50;
    pig[0].texture.height = 50;
    
    if (pageState == GAME3_PAGE) {
        pig[0].x = 830;
        pig[0].y = groundY-25;
    }
    
    if (pageState == GAME2_PAGE) {
        pig[0].x = 745;
        pig[0].y = 370;
    }
    
    if (pageState == GAME1_PAGE) {
        pig[0].x = 700;
        pig[0].y = 315;
    }
    
}


int isItOutOfArea(Bird *bird){
    if (bird->y >= groundY || bird->x <= 0 || bird->x >= GetScreenWidth()) {
        return 1;
    }
    else{
        return 0;
    }
}

bool CheckCollisionWithPig(Bird *bird, Pig *pig) {
    Rectangle birdRect = { bird->x, bird->y, bird->texture.width, bird->texture.height }; // Kuşun dikdörtgen sınırları
    Rectangle pigRect = { pig->x, pig->y, pig->texture.width, pig->texture.height }; // Domuzun dikdörtgen sınırları
    return CheckCollisionRecs(birdRect, pigRect); // Kuş ve domuz arasında çarpışma kontrolü
}

bool CheckCollisionWithBlock(Bird *bird, Rectangle Block) {
    Rectangle birdRect = { bird->x, bird->y, bird->texture.width, bird->texture.height };
    return CheckCollisionRecs(birdRect, Block); 
}

void resetGame(Bird *birds, Pig *pigs, Wood_v *woodV, Wood_h *woodH, bool *isCollision, PageState pageState) {
    initializeBird(birds);
    initializePig(pigs, pageState);
    initializeWood(woodV, woodH, isCollision, pageState);
}

void findScore(Bird *birds, Pig *pigs, Wood_v *woodV, Wood_h *woodH, bool *isCollision, Texture2D *scoreTable, PageState *pageState){
    Rectangle scoreRestartButton = {475, 298, 50, 50};
    Rectangle scoreResumeButton = {575, 298, 50, 50};
    
    int thBirds = 0;
    for (int i = 0; i < 3; i++) {
        if(birds[i].isBirdFired && birds[i].velocity.x == 0 && birds[i].velocity.y == 0){
            thBirds++;
        }
    }
    
    int pigsDestroyed = 0;
    
    if (pigs[0].x == -100 && pigs[0].y == -100) {
        pigsDestroyed++;
    }
    
    
    if (thBirds == 3 && pigsDestroyed == numberPigs){
        DrawTexture(scoreTable[1], 0, 0, WHITE);
    }
    
    if (thBirds == 2 && pigsDestroyed == numberPigs && birds[2].isBirdFired == false){
        DrawTexture(scoreTable[2], 0, 0, WHITE);
    }
    
    if (thBirds == 1 && pigsDestroyed == numberPigs && birds[1].isBirdFired == false){
        DrawTexture(scoreTable[3], 0, 0, WHITE);
    }

    if (thBirds == 3 && pigsDestroyed == 0){
        DrawTexture(scoreTable[0], 0, 0, WHITE);
    }
    
    
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), scoreResumeButton)) {
        if(*pageState == GAME3_PAGE){
            *pageState = MAIN_PAGE;
        }
        if(*pageState == GAME2_PAGE){
            *pageState = GAME3_PAGE;
            resetGame(birds, pigs, woodV, woodH, isCollision, *pageState);
        }
        if(*pageState == GAME1_PAGE){
            *pageState = GAME2_PAGE;
            resetGame(birds, pigs, woodV, woodH, isCollision, *pageState);
        }
    }
    
    if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON) && CheckCollisionPointRec(GetMousePosition(), scoreRestartButton)) {
        resetGame(birds, pigs, woodV, woodH, isCollision, *pageState);
    }
    
}

CollesionResult checkCollisionBirdWood(Bird* bird, Wood_v* wood) {
    
    CollesionResult result;
    
    result.collesion = false;
    result.bird = bird[0];
    
    Rectangle birdRect1 = { bird[0].x, bird[0].y, bird[0].texture.width, bird[0].texture.height };
    Rectangle birdRect2 = { bird[1].x, bird[1].y, bird[1].texture.width, bird[1].texture.height };
    Rectangle birdRect3 = { bird[2].x, bird[2].y, bird[2].texture.width, bird[2].texture.height };
    
    Rectangle woodRect = { wood->x, wood->y, wood->texture.width, wood->texture.height };
    
    if (CheckCollisionRecs(birdRect1, woodRect)) {
        result.collesion = CheckCollisionRecs(birdRect1, woodRect);
        result.bird = bird[0];
        
        return result;
    }
    
    if (CheckCollisionRecs(birdRect2, woodRect)) {
        result.collesion = CheckCollisionRecs(birdRect2, woodRect);
        result.bird = bird[1];
        
        return result;
    }
    
    if (CheckCollisionRecs(birdRect3, woodRect)) {
        result.collesion = CheckCollisionRecs(birdRect3, woodRect);
        result.bird = bird[2];
        
        return result;
    }
    
    return result;
}

CollesionResult checkCollisionBirdWoodh(Bird* bird, Wood_h* wood) {
    
    CollesionResult result;
    
    result.collesion = false;
    result.bird = bird[0];
    
    Rectangle birdRect1 = { bird[0].x, bird[0].y, bird[0].texture.width, bird[0].texture.height };
    Rectangle birdRect2 = { bird[1].x, bird[1].y, bird[1].texture.width, bird[1].texture.height };
    Rectangle birdRect3 = { bird[2].x, bird[2].y, bird[2].texture.width, bird[2].texture.height };
    
    Rectangle woodRect = { wood->x, wood->y, wood->texture.width, wood->texture.height };
    
    if (CheckCollisionRecs(birdRect1, woodRect)) {
        result.collesion = CheckCollisionRecs(birdRect1, woodRect);
        result.bird = bird[0];
        
        return result;
    }
    
    if (CheckCollisionRecs(birdRect2, woodRect)) {
        result.collesion = CheckCollisionRecs(birdRect2, woodRect);
        result.bird = bird[1];
        
        return result;
    }
    
    if (CheckCollisionRecs(birdRect3, woodRect)) {
        result.collesion = CheckCollisionRecs(birdRect3, woodRect);
        result.bird = bird[2];
        
        return result;
    }
    
    return result;
}

void updateWood(Wood_v* woodV){
    
    // YUKARIDAKİ İÇİN
    
    if (woodV->isItAbove){
        if (woodV->y < 295){
            // YUKARIDAKI CUBUGUN YERE DUSMESI
            
            woodV->position.y += 100 * GetFrameTime(); 
            woodV->y += 100 * GetFrameTime(); 
        }
    }
    
    
    if(woodV->collapseRight){
        
        woodV->rotation += GetFrameTime() * 90; // 90 derece/saniye dönme hızı
        
        if (woodV->rotation >= 90.0f){
            woodV->rotation = 90.0f; // 90 dereceyi aşmayacak şekilde sınırlama
            
            // DONMEYI BITIRDIKTEN SONRA EĞER YERDEYSE SIL!
            if (woodV->y <= 295) {
                
                woodV->y = 1000;
                woodV->x = 1000;
                woodV->position.y = 1000;
                woodV->position.x = 1000;
            }
            
            woodV -> collapseFinished = true;
        }
    }
    else{
        
        woodV->rotation -= GetFrameTime() * 90; // 90 derece/saniye dönme hızı
        
        if (woodV->rotation <= -90.0f){
            woodV->rotation = -90.0f; // 90 dereceyi aşmayacak şekilde sınırlama
            
            // DONMEYI BITIRDIKTEN SONRA SIL
            woodV->y = 1000;
            woodV->x = 1000;
            woodV->position.y = 1000;
            woodV->position.x = 1000;
            
            
            woodV -> collapseFinished = true;
        }
        
    
    }
    
    DrawTexturePro(woodV->texture, woodV->sourceRec, (Rectangle){ woodV->position.x, woodV->position.y, woodV->texture.width, woodV->texture.height }, woodV->origin, woodV->rotation, WHITE);
    
}

void checkCollision(Bird *birds, Wood_v *woodV, Wood_h *woodH){
    
    // YATAY OLANIN YIKILMASI
    
    if (woodV->collisionDetected || woodH->collisionDetected) {
        
        woodH->collapse = true;
        woodV->collapse = true;
        
        if ( (birds->y + birds->texture.height <= woodV->y + woodV->texture.height / 2 + 3)) {
            woodV->collapseRight = true;
            (woodV+1)->collapseRight = true;
            
            // DÖNME NOKTALARININ AYARLANMASI ESTETİK GÖRÜNTÜ
            woodV->position = (Vector2) { woodV->x + woodV->texture.width, woodV->y + woodV->texture.height};
            woodV->sourceRec = (Rectangle) { 0, 0, woodV->texture.width, woodV->texture.height }; // Kaynak dikdörtgen, tüm resmi kapsar
            woodV->origin = (Vector2) {woodV->texture.width, woodV->texture.height }; // Döndürme merkezi, resmin sağ alt köşesinde
            woodV->rotation = 0.0f;
            
            (woodV+1)->position = (Vector2) { (woodV+1)->x + (woodV+1)->texture.width, (woodV+1)->y + (woodV+1)->texture.height};
            (woodV+1)->sourceRec = (Rectangle) { 0, 0, (woodV+1)->texture.width, (woodV+1)->texture.height }; // Kaynak dikdörtgen, tüm resmi kapsar
            (woodV+1)->origin = (Vector2) {(woodV+1)->texture.width, (woodV+1)->texture.height }; // Döndürme merkezi, resmin sağ alt köşesinde
            (woodV+1)->rotation = 0.0f;
            
        }
        // Kuş çubuğun alt yarısına çarptıysa çubuk sola doğru 90 derece döner 
        if ((birds->y + birds->texture.height > woodV->y + woodV->texture.height / 2 + 3)) {
            woodV->collapseRight = false;
            (woodV+1)->collapseRight = false;    // Sola doğru dönme  
            
            woodV->position = (Vector2) { woodV->x + woodV->texture.width, woodV->y + woodV->texture.height};
            woodV->sourceRec = (Rectangle) { 0, 0, woodV->texture.width, woodV->texture.height }; // Kaynak dikdörtgen, tüm resmi kapsar
            woodV->origin = (Vector2) {0, woodV->texture.height }; // Döndürme merkezi, resmin sağ alt köşesinde
            woodV->rotation = 0.0f;
            
            (woodV+1)->position = (Vector2) { (woodV+1)->x + (woodV+1)->texture.width, (woodV+1)->y + (woodV+1)->texture.height};
            (woodV+1)->sourceRec = (Rectangle) { 0, 0, (woodV+1)->texture.width, (woodV+1)->texture.height }; // Kaynak dikdörtgen, tüm resmi kapsar
            (woodV+1)->origin = (Vector2) {0, (woodV+1)->texture.height }; // Döndürme merkezi, resmin sağ alt köşesinde
            (woodV+1)->rotation = 0.0f;
            
        }

    }
    
    if (woodH->collapse) {
        
        if (woodH->y < 390) {
            if (woodV->collapseRight) {
                woodH->y += 140 * GetFrameTime();  // Aşağı ve yana doğru düşmesi için y koordinatını artır 
                woodH->x += 110.5f * GetFrameTime();  // SAĞ
            }
            else {
                woodH->y += 140 * GetFrameTime();  // Aşağı ve yana doğru düşmesi için y koordinatını artır 
                woodH->x -= 100 * GetFrameTime();  // SOL
            }
        }
        
        if (woodH->isItAbove && woodH->y >= 265) {
            // SADECE YUKARIDAKİ YIKILIRSA ALTTAKİ ÇUBUKLARA DEĞİNCE KIR
            woodH->x = 1000;
            woodH->y = 1000;
        }
        
        if(!woodH->isItAbove && woodH->y >= 390){
            // YERE DEĞİNCE SİLİYOR.
            
            woodH->x = 1000;
            woodH->y = 1000;
        }
    }
    
    
    // DİKEY OLANIN YIKILMASI

    if (woodV->collapse) {
        updateWood(woodV); 
        updateWood(woodV+1);
        
    }else{
        DrawTexture(woodV->texture, woodV->x, woodV->y, WHITE);
        DrawTexture((woodV+1)->texture, (woodV+1)->x, (woodV+1)->y, WHITE);
    }
    
    
    
}

void initializeWood(Wood_v *woodV, Wood_h *woodH, bool *isCollision, PageState pageState){
    for (int i = 0; i < 6; i++) {
        woodV[i].texture = LoadTexture("TexturesAudio/wood_v.png");
    }
    for (int i = 0; i < 3; i++) {
        woodH[i].texture = LoadTexture("TexturesAudio/wood_w.png");
    }
    
    if(pageState == GAME3_PAGE){
        //1
        woodH[0].x = 650;
        woodH[0].y = 290 - 10;

        woodV[0].x = 650;
        woodV[0].y = 295;

        woodV[1].x = 766;
        woodV[1].y = 295;
        
        //2
        woodH[1].x = 650 + 134 + 5;
        woodH[1].y = 290 - 10;

        woodV[2].x = 650 + 134 + 5;
        woodV[2].y = 295;

        woodV[3].x = 766 + 134 + 5;
        woodV[3].y = 295;
        
        //3
        
        woodH[2].x = 650 + 134/2;
        woodH[2].y = 290 - 140 - 10;

        woodV[4].x = 650 + 134/2;
        woodV[4].y = 295 - 130 - 10;

        woodV[5].x = 766 + 134/2;
        woodV[5].y = 295 - 130 - 10;
        
        woodV[4].isItAbove = false;
        woodV[5].isItAbove = false;
        woodH[2].isItAbove = true;
        
        for (int i = 0; i < 6; i++) {
            woodV[i].collisionDetected = false;
            woodV[i].collapse = false;
            woodV[i].collapseFinished = false;
            woodV[i].collapseRight = false;
        }
        for (int i = 0; i < 3; i++) {
            woodH[i].collisionDetected = false;
            woodH[i].collapse = false;
        }
        
        *isCollision = false;
    
        
    }
    
    if (pageState == GAME2_PAGE){
        //1
        woodH[0].x = 700;
        woodH[0].y = 290 - 10;

        woodV[0].x = 700;
        woodV[0].y = 295;

        woodV[1].x = 816;
        woodV[1].y = 295;
        
        for (int i = 0; i < 6; i++) {
            woodV[i].collisionDetected = false;
            woodV[i].collapse = false;
            woodV[i].collapseFinished = false;
            woodV[i].collapseRight = false;
        }
        for (int i = 0; i < 3; i++) {
            woodH[i].collisionDetected = false;
            woodH[i].collapse = false;
        }
        
    }
    
}

void rightToLaunch(Bird *birds, Texture2D textureForTable){
    if (!birds[0].isBirdFired && !birds[1].isBirdFired && !birds[2].isBirdFired) {
        DrawTexture(textureForTable, 875, 30, WHITE);
        DrawTexture(textureForTable, 875 + 40 + 18, 30, WHITE);
        DrawTexture(textureForTable, 875 + 40 + 18 + 40 + 18, 30, WHITE);
    }
    
    if (birds[0].isBirdFired && !birds[1].isBirdFired && !birds[2].isBirdFired) {
        DrawTexture(textureForTable, 875, 30, WHITE);
        DrawTexture(textureForTable, 875 + 40 + 18, 30, WHITE);
    }
    
    if (birds[0].isBirdFired && birds[1].isBirdFired & !birds[2].isBirdFired) {
        DrawTexture(textureForTable, 875, 30, WHITE);
    }
    
    if (birds[0].isBirdFired && birds[1].isBirdFired && birds[2].isBirdFired) {
        NULL;
    }
     
}

void initializeButtons(Rectangle *playButton, Rectangle *game1Button, Rectangle *game2Button, Rectangle *game3Button, Rectangle *gameBackButton, Rectangle *gameRestartButton, Rectangle *mainBackButton, Rectangle *closeButton, Rectangle *infoButton){
    
    *playButton = (Rectangle) { 494, 251, 112, 112 };
    *game1Button = (Rectangle) { 340, 140, 110, 110 };
    *game2Button = (Rectangle) { 496, 140, 110, 110 };
    *game3Button = (Rectangle) { 652, 140, 110, 110 };
    *gameBackButton = (Rectangle) {20, 20, 50, 50 };
    *gameRestartButton = (Rectangle) {81, 20, 50, 50};
    *mainBackButton = (Rectangle) {50, 50, 60, 60};
    *closeButton = (Rectangle) {1008, 20, 60, 60};
    *infoButton = (Rectangle) {1008, 95, 60, 60};
}

void initializePageTextures(Texture2D *mainPage, Texture2D *menuPage, Texture2D *infoScreen, Texture2D *scoreTable, Texture2D *textureForTable, int screenWidth, int screenHeight){
    *mainPage = LoadTexture("TexturesAudio/mainPage.png");
    *menuPage = LoadTexture("TexturesAudio/menuPage.png");
    *infoScreen = LoadTexture("TexturesAudio/infoScreen2.png");
    scoreTable[0] = LoadTexture("TexturesAudio/score0Stars.png");
    scoreTable[0].width = screenWidth;
    scoreTable[0].height = screenHeight;
    scoreTable[1] = LoadTexture("TexturesAudio/score1Stars.png");
    scoreTable[1].width = screenWidth;
    scoreTable[1].height = screenHeight;
    scoreTable[2] = LoadTexture("TexturesAudio/score2Stars.png");
    scoreTable[2].width = screenWidth;
    scoreTable[2].height = screenHeight;
    scoreTable[3] = LoadTexture("TexturesAudio/score3Stars.png");
    scoreTable[3].width = screenWidth;
    scoreTable[3].height = screenHeight;
    
    *textureForTable = LoadTexture("TexturesAudio/redBird.png");
    (*textureForTable).width = 40;
    (*textureForTable).height = 40;
}

void initializeGameObjects(Texture2D *catapult, Texture2D *pigExplosion, Texture2D *ground, Texture2D *stoneBlock){
    *catapult = LoadTexture("TexturesAudio/catapult.png");
    catapult->width /= 5;
    catapult->height /= 5;
    *ground = LoadTexture("TexturesAudio/ground.png");
    *pigExplosion = LoadTexture("TexturesAudio/pigExplosion.png");
    pigExplosion->width = 50;
    pigExplosion->height = 50;
    *stoneBlock = LoadTexture("TexturesAudio/stoneBlock.png");
    stoneBlock->width = 60;
    stoneBlock->height = 60;
}
